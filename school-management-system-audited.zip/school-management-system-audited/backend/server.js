
require("dotenv").config();

const app = require("./src/app");
const connectDB = require("./src/config/database");

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    // Check JWT Secret
    if (!process.env.JWT_SECRET) {
      throw new Error("JWT_SECRET is missing in .env file");
    }

    // Connect Database
    await connectDB();

    // Start Server
    const server = app.listen(PORT, () => {
      console.log("-----------------------------------");
      console.log("School Management System Backend");
      console.log(`Server running on port ${PORT}`);
      console.log("MongoDB Connected Successfully");
      console.log("-----------------------------------");
    });

    // Graceful Shutdown
    const shutdown = (signal) => {
      console.log(`${signal} received. Shutting down server...`);

      server.close(() => {
        console.log("Server closed successfully.");
        process.exit(0);
      });
    };

    process.on("SIGTERM", () => shutdown("SIGTERM"));
    process.on("SIGINT", () => shutdown("SIGINT"));

  } catch (error) {
    console.error("Server startup failed:", error.message);
    process.exit(1);
  }
};

startServer();
