
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");

const errorHandler = require("./middlewares/errorMiddleware");
const { authLimiter } = require("./middlewares/rateLimiters");

const app = express();

// ======================================
// CORS CONFIGURATION
// ======================================

const configuredOrigins = (process.env.CLIENT_URL || "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

const defaultDevelopmentOrigins =
  process.env.NODE_ENV === "production"
    ? []
    : ["http://localhost:3000", "http://localhost:5173"];

// ======================================
// SECURITY MIDDLEWARE
// ======================================

app.use(helmet());

app.use(
  cors({
    origin(origin, callback) {
      if (!origin) return callback(null, true);

      const allowed = configuredOrigins.length
        ? configuredOrigins
        : defaultDevelopmentOrigins;

      if (allowed.includes(origin)) {
        return callback(null, true);
      }

      return callback(new Error("Origin is not allowed by CORS"));
    },
    credentials: true,
  })
);

// ======================================
// GENERAL MIDDLEWARE
// ======================================

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

app.use(cookieParser());

app.use(
  morgan(
    process.env.NODE_ENV === "production" ? "combined" : "dev"
  )
);

// ======================================
// ROUTE IMPORTS
// ======================================

const authRoutes = require("./routes/authRoutes");
const superAdminRoutes = require("./routes/superAdminRoutes");

const schoolRoutes = require("./routes/schoolRoutes");
const branchRoutes = require("./routes/branchRoutes");
const userRoutes = require("./routes/userRoutes");

const studentRoutes = require("./routes/studentRoutes");
const teacherRoutes = require("./routes/teacherRoutes");
const parentRoutes = require("./routes/parentRoutes");
const principalRoutes = require("./routes/principalRoutes");
const adminRoutes = require("./routes/adminRoutes");

// ======================================
// HEALTH CHECK
// ======================================

app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "School Management System API is Running!",
  });
});

// ======================================
// API ROUTES
// ======================================

// Authentication
app.use("/api/auth", authLimiter, authRoutes);

// Super Admin
app.use("/api/super-admin", authLimiter, superAdminRoutes);

// School Management
app.use("/api/schools", schoolRoutes);
app.use("/api/branches", branchRoutes);
app.use("/api/users", userRoutes);

// Role-Based Management
app.use("/api/students", studentRoutes);
app.use("/api/teachers", teacherRoutes);
app.use("/api/parents", parentRoutes);
app.use("/api/principals", principalRoutes);
app.use("/api/admins", adminRoutes);

// ======================================
// 404 HANDLER
// ======================================

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "API route not found.",
  });
});

// ======================================
// GLOBAL ERROR HANDLER
// ======================================

app.use(errorHandler);

module.exports = app;
