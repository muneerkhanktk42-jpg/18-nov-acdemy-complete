
const User = require("../models/User");
const School = require("../models/School");
const Branch = require("../models/Branch");
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");

const ROLE_LEVEL = {
  super_admin: 100,
  owner: 90,
  principal: 80,
  admin: 70,
  teacher: 60,
  student: 50,
  parent: 40,
};

const canManageTargetUser = (actor, target) => {
  if (!actor || !target) return false;
  if (actor.id === target._id.toString()) return false;
  if (actor.roles.includes("super_admin")) return !target.roles.includes("super_admin");
  if (target.roles.includes("super_admin") || target.roles.includes("owner")) return false;
  const actorLevel = Math.max(...actor.roles.map((role) => ROLE_LEVEL[role] || 0));
  const targetLevel = Math.max(...target.roles.map((role) => ROLE_LEVEL[role] || 0));
  return actorLevel > targetLevel;
};

const getSchoolId = (req) => {
  if (req.user.roles.includes("super_admin")) {
    return req.params.schoolId || req.body.schoolId || req.query.schoolId;
  }

  return req.user.school;
};

const getAllowedRoles = (req) => {
  const roles = req.user.roles;

  if (roles.includes("super_admin")) {
    return ["owner"];
  }

  if (roles.includes("owner")) {
    return ["principal", "admin", "teacher", "student", "parent"];
  }

  if (roles.includes("principal") || roles.includes("admin")) {
    return ["teacher", "student", "parent"];
  }

  return [];
};

// Create user
exports.createUser = async (req, res, next) => {
  try {
    const { name, email, password, phone, roles, branches } = req.body;

    if (
      typeof name !== "string" ||
      typeof email !== "string" ||
      typeof password !== "string" ||
      !name.trim() ||
      !email.trim() ||
      !password ||
      !Array.isArray(roles) ||
      !roles.length
    ) {
      return res.status(400).json({
        success: false,
        message: "Name, email, password and roles are required",
      });
    }

    if (password.length < 8 || password.length > 128) {
      return res.status(400).json({
        success: false,
        message: "Password must be between 8 and 128 characters",
      });
    }

    const allowedRoles = getAllowedRoles(req);

    if (!roles.every((role) => allowedRoles.includes(role))) {
      return res.status(403).json({
        success: false,
        message: "You are not allowed to assign one or more selected roles",
      });
    }

    const schoolId = getSchoolId(req);

    if (!schoolId || !mongoose.isValidObjectId(schoolId)) {
      return res.status(400).json({
        success: false,
        message: "Valid school ID is required",
      });
    }

    const school = await School.findById(schoolId);

    if (!school || school.status !== "active") {
      return res.status(404).json({
        success: false,
        message: "Active school not found",
      });
    }

    if (
      !req.user.roles.includes("super_admin") &&
      school._id.toString() !== req.user.school?.toString()
    ) {
      return res.status(403).json({
        success: false,
        message: "You cannot create users for another school",
      });
    }

    const normalizedEmail = email.toLowerCase().trim();

    const existingUser = await User.findOne({
      email: normalizedEmail,
    });

    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: "Email already exists",
      });
    }

    const branchIds = branches || [];

    if (!Array.isArray(branchIds)) {
      return res.status(400).json({
        success: false,
        message: "Branches must be an array",
      });
    }

    const uniqueBranchIds = [...new Set(branchIds.map(String))];

    if (uniqueBranchIds.some((id) => !mongoose.isValidObjectId(id))) {
      return res.status(400).json({
        success: false,
        message: "Invalid branch ID",
      });
    }

    if (uniqueBranchIds.length) {
      const validBranches = await Branch.countDocuments({
        _id: { $in: uniqueBranchIds },
        school: schoolId,
        status: "active",
      });

      if (validBranches !== uniqueBranchIds.length) {
        return res.status(400).json({
          success: false,
          message: "One or more branches are invalid or inactive",
        });
      }
    }

    const needsBranch = roles.some((role) =>
      ["teacher", "student"].includes(role)
    );

    if (needsBranch && uniqueBranchIds.length === 0) {
      return res.status(400).json({
        success: false,
        message: "At least one branch is required for teachers and students",
      });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const user = await User.create({
      name,
      email: normalizedEmail,
      password: hashedPassword,
      phone: phone || "",
      roles,
      school: schoolId,
      branches: uniqueBranchIds,
    });

    res.status(201).json({
      success: true,
      message: "User created successfully",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        roles: user.roles,
        school: user.school,
        branches: user.branches,
        status: user.status,
      },
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Email already exists",
      });
    }
    next(error);
  }
};

// Get users of a school
exports.getUsers = async (req, res, next) => {
  try {
    const schoolId = getSchoolId(req);

    if (!schoolId || !mongoose.isValidObjectId(schoolId)) {
      return res.status(400).json({
        success: false,
        message: "Valid school ID is required",
      });
    }

    const filter = { school: schoolId };

    // Managers must not receive account records above their management level.
    if (!req.user.roles.includes("super_admin")) {
      const visibleRoles = getAllowedRoles(req);
      if (!visibleRoles.length) {
        return res.status(403).json({
          success: false,
          message: "You are not allowed to view user accounts.",
        });
      }
      filter.roles = { $in: visibleRoles };
      if (req.query.role) {
        if (!visibleRoles.includes(req.query.role)) {
          return res.status(403).json({
            success: false,
            message: "You are not allowed to view this user role.",
          });
        }
        filter.roles = req.query.role;
      }
    } else if (req.query.role) {
      filter.roles = req.query.role;
    }

    if (req.query.status) {
      filter.status = req.query.status;
    }

    const users = await User.find(filter)
      .select("-password")
      .populate("branches", "name branchCode")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: users.length,
      users,
    });
  } catch (error) {
    next(error);
  }
};

// Update user
exports.updateUser = async (req, res, next) => {
  try {
    const schoolId = getSchoolId(req);
    const { id } = req.params;

    if (
      !mongoose.isValidObjectId(id) ||
      !schoolId ||
      !mongoose.isValidObjectId(schoolId)
    ) {
      return res.status(400).json({
        success: false,
        message: "Valid user and school IDs are required",
      });
    }

    const user = await User.findOne({
      _id: id,
      school: schoolId,
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found in this school",
      });
    }

    if (!canManageTargetUser(req.user, user)) {
      return res.status(403).json({
        success: false,
        message: "You are not allowed to modify this account.",
      });
    }

    const allowedFields = ["name", "phone", "status"];

    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        user[field] = req.body[field];
      }
    });

    if (
      req.body.status &&
      !["active", "inactive", "suspended"].includes(req.body.status)
    ) {
      return res.status(400).json({
        success: false,
        message: "Invalid user status",
      });
    }

    await user.save();

    res.status(200).json({
      success: true,
      message: "User updated successfully",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        roles: user.roles,
        school: user.school,
        branches: user.branches,
        status: user.status,
      },
    });
  } catch (error) {
    next(error);
  }
};

// Deactivate user
exports.deactivateUser = async (req, res, next) => {
  try {
    const schoolId = getSchoolId(req);
    const { id } = req.params;

    if (
      !mongoose.isValidObjectId(id) ||
      !schoolId ||
      !mongoose.isValidObjectId(schoolId)
    ) {
      return res.status(400).json({
        success: false,
        message: "Valid user and school IDs are required",
      });
    }

    const user = await User.findOne({ _id: id, school: schoolId });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    if (!canManageTargetUser(req.user, user)) {
      return res.status(403).json({
        success: false,
        message: "You are not allowed to deactivate this account.",
      });
    }

    user.status = "inactive";
    await user.save();

    res.status(200).json({
      success: true,
      message: "User deactivated successfully",
      user: user.toObject({ transform: (doc, ret) => { delete ret.password; return ret; } }),
    });
  } catch (error) {
    next(error);
  }
};
