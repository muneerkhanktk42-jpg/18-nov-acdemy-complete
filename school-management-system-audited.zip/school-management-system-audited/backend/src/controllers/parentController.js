
const ParentProfile = require("../models/ParentProfile");
const createProfileController = require("../utils/profileControllerFactory");

module.exports = createProfileController(
  ParentProfile,
  "parent",
  [
    "students",
    "occupation",
    "address",
    "emergencyContact",
  ],
  ["owner", "principal", "admin"]
);
