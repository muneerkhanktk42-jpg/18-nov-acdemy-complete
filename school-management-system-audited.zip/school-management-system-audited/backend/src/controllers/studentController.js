
const StudentProfile = require("../models/StudentProfile");
const createProfileController = require("../utils/profileControllerFactory");

module.exports = createProfileController(
  StudentProfile,
  "student",
  [
    "branch",
    "admissionNumber",
    "class",
    "section",
    "rollNumber",
    "dateOfBirth",
    "gender",
    "bloodGroup",
    "address",
    "admissionDate",
    "status",
  ],
  ["owner", "principal", "admin"]
);
