
const School = require("../models/School");
const User = require("../models/User");
const mongoose = require("mongoose");

// Create school for logged-in owner
exports.createSchool = async (req, res, next) => {
  try {
    const { name, schoolCode, email, phone, address } = req.body;

    if (!name || !schoolCode || !email || !phone || !address) {
      return res.status(400).json({
        success: false,
        message: "All school fields are required",
      });
    }

    const owner = await User.findById(req.user.id);

    if (!owner || !owner.roles.includes("owner")) {
      return res.status(403).json({
        success: false,
        message: "Only school owners can create a school",
      });
    }

    if (owner.school) {
      return res.status(400).json({
        success: false,
        message: "This owner already has a school",
      });
    }

    const school = await School.create({
      name,
      schoolCode,
      email,
      phone,
      address,
      owner: owner._id,
    });

    owner.school = school._id;
    await owner.save();

    res.status(201).json({
      success: true,
      message: "School created successfully",
      school,
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "School code already exists",
      });
    }
    next(error);
  }
};

// Get logged-in owner's school
exports.getMySchool = async (req, res, next) => {
  try {
    const school = await School.findOne({
      owner: req.user.id,
    });

    if (!school) {
      return res.status(404).json({
        success: false,
        message: "School not found",
      });
    }

    res.status(200).json({
      success: true,
      school,
    });
  } catch (error) {
    next(error);
  }
};

// Update school
exports.updateSchool = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid school ID",
      });
    }

    const school = await School.findById(id);

    if (!school) {
      return res.status(404).json({
        success: false,
        message: "School not found",
      });
    }

    const isSuperAdmin = req.user.roles.includes("super_admin");
    const isOwner = school.owner.toString() === req.user.id.toString();

    if (!isSuperAdmin && !isOwner) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to update this school",
      });
    }

    const allowedFields = ["name", "email", "phone", "address"];

    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        school[field] = req.body[field];
      }
    });

    await school.save();

    res.status(200).json({
      success: true,
      message: "School updated successfully",
      school,
    });
  } catch (error) {
    next(error);
  }
};

// Super Admin: Get all schools
exports.getAllSchools = async (req, res, next) => {
  try {
    const schools = await School.find()
      .populate("owner", "name email")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: schools.length,
      schools,
    });
  } catch (error) {
    next(error);
  }
};

// Super Admin: Update school status
exports.updateSchoolStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const { id } = req.params;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid school ID",
      });
    }

    if (!["active", "inactive", "suspended"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Invalid school status",
      });
    }

    const school = await School.findByIdAndUpdate(
      id,
      { status },
      { new: true, runValidators: true }
    );

    if (!school) {
      return res.status(404).json({
        success: false,
        message: "School not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "School status updated",
      school,
    });
  } catch (error) {
    next(error);
  }
};
