
const AdminProfile = require("../models/AdminProfile");
const  createProfileController = require("../utils/profileControllerFactory");

module.exports = createProfileController(
  AdminProfile,
  "admin",
  [
    "branches",
    "employeeId",
    "designation",
    "phone",
    "address",
    "joiningDate",
    "status",
  ],
  ["owner", "principal"]
);
