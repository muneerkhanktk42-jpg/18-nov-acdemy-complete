
const PrincipalProfile = require("../models/PrincipalProfile");
const createProfileController = require("../utils/profileControllerFactory");

module.exports = createProfileController(
  PrincipalProfile,
  "principal",
  [
    "branches",
    "employeeId",
    "qualification",
    "experience",
    "phone",
    "joiningDate",
    "status",
  ],
  ["owner"]
);
