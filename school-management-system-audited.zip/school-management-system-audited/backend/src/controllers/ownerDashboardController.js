
const School = require("../models/School");
const Branch = require("../models/Branch");
const User = require("../models/User");

// ======================================
// OWNER DASHBOARD
// ======================================

exports.getOwnerDashboard = async (req, res, next) => {
  try {
    const schoolId = req.user.school;

    if (!schoolId) {
      return res.status(404).json({
        success: false,
        message: "No school is assigned to this owner",
      });
    }

    const school = await School.findOne({
      _id: schoolId,
      owner: req.user.id,
    }).populate("owner", "name email phone");

    if (!school) {
      return res.status(404).json({
        success: false,
        message: "School not found",
      });
    }

    const [
      totalBranches,
      activeBranches,
      inactiveBranches,
      totalUsers,
      activeUsers,
      inactiveUsers,
      roleWiseUsers,
      recentUsers,
    ] = await Promise.all([
      Branch.countDocuments({ school: schoolId }),
      Branch.countDocuments({ school: schoolId, status: "active" }),
      Branch.countDocuments({ school: schoolId, status: "inactive" }),

      User.countDocuments({ school: schoolId }),
      User.countDocuments({ school: schoolId, status: "active" }),
      User.countDocuments({ school: schoolId, status: "inactive" }),

      User.aggregate([
        { $match: { school: school._id } },
        { $unwind: "$roles" },
        {
          $group: {
            _id: "$roles",
            total: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),

      User.find({ school: schoolId })
        .select("name email roles status createdAt")
        .sort({ createdAt: -1 })
        .limit(5)
        .lean(),
    ]);

    return res.status(200).json({
      success: true,
      message: "Owner dashboard fetched successfully",

      dashboard: {
        school: {
          id: school._id,
          name: school.name,
          schoolCode: school.schoolCode,
          status: school.status,
          owner: school.owner,
        },

        branches: {
          total: totalBranches,
          active: activeBranches,
          inactive: inactiveBranches,
        },

        users: {
          total: totalUsers,
          active: activeUsers,
          inactive: inactiveUsers,
        },

        roleWiseUsers: roleWiseUsers.map((item) => ({
          role: item._id,
          total: item.total,
        })),

        recentUsers,
      },
    });
  } catch (error) {
    next(error);
  }
};
