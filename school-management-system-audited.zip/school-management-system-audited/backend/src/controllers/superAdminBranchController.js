
const mongoose = require("mongoose");
const Branch = require("../models/Branch");

const escapeRegex = (value) =>
  value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// ======================================
// GET ALL BRANCHES
// ======================================
exports.getAllBranches = async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(
      Math.max(parseInt(req.query.limit, 10) || 10, 1),
      100
    );

    const { search, status, schoolId } = req.query;

    const filter = {};

    if (search && search.trim()) {
      const regex = new RegExp(escapeRegex(search.trim()), "i");

      filter.$or = [
        { name: regex },
        { branchCode: regex },
        { email: regex },
      ];
    }

    if (status) {
      if (!["active", "inactive"].includes(status)) {
        return res.status(400).json({
          success: false,
          message: "Invalid branch status",
        });
      }

      filter.status = status;
    }

    if (schoolId) {
      if (!mongoose.isValidObjectId(schoolId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid school ID",
        });
      }

      filter.school = schoolId;
    }

    const skip = (page - 1) * limit;

    const [branches, total] = await Promise.all([
      Branch.find(filter)
        .populate("school", "name schoolCode status")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),

      Branch.countDocuments(filter),
    ]);

    return res.status(200).json({
      success: true,
      count: branches.length,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
        hasNextPage: page * limit < total,
        hasPrevPage: page > 1,
      },
      branches,
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// GET SINGLE BRANCH DETAILS
// ======================================
exports.getBranchDetails = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid branch ID",
      });
    }

    const branch = await Branch.findById(id)
      .populate("school", "name schoolCode status")
      .lean();

    if (!branch) {
      return res.status(404).json({
        success: false,
        message: "Branch not found",
      });
    }

    return res.status(200).json({
      success: true,
      branch,
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// UPDATE BRANCH STATUS
// ======================================
exports.updateBranchStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid branch ID",
      });
    }

    if (!["active", "inactive"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Status must be active or inactive",
      });
    }

    const branch = await Branch.findById(id);

    if (!branch) {
      return res.status(404).json({
        success: false,
        message: "Branch not found",
      });
    }

    branch.status = status;
    await branch.save();

    const updatedBranch = await Branch.findById(id)
      .populate("school", "name schoolCode status")
      .lean();

    return res.status(200).json({
      success: true,
      message: "Branch status updated successfully",
      branch: updatedBranch,
    });
  } catch (error) {
    next(error);
  }
};
