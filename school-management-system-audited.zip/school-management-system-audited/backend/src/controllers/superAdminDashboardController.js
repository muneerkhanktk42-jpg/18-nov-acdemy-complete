
const mongoose = require("mongoose");

const User = require("../models/User");
const School = require("../models/School");
const Branch = require("../models/Branch");

// ======================================
// SUPER ADMIN DASHBOARD STATISTICS
// ======================================

exports.getDashboardStats = async (req, res, next) => {
  try {
    const [
      totalSchools,
      activeSchools,
      inactiveSchools,
      suspendedSchools,
      totalBranches,
      activeBranches,
      totalUsers,
      totalOwners,
      totalPrincipals,
      totalAdmins,
      totalTeachers,
      totalStudents,
      totalParents,
    ] = await Promise.all([
      School.countDocuments(),
      School.countDocuments({ status: "active" }),
      School.countDocuments({ status: "inactive" }),
      School.countDocuments({ status: "suspended" }),

      Branch.countDocuments(),
      Branch.countDocuments({ status: "active" }),

      User.countDocuments({ roles: { $ne: "super_admin" } }),
      User.countDocuments({ roles: "owner" }),
      User.countDocuments({ roles: "principal" }),
      User.countDocuments({ roles: "admin" }),
      User.countDocuments({ roles: "teacher" }),
      User.countDocuments({ roles: "student" }),
      User.countDocuments({ roles: "parent" }),
    ]);

    return res.status(200).json({
      success: true,
      message: "Super Admin dashboard statistics fetched successfully",
      dashboard: {
        schools: {
          total: totalSchools,
          active: activeSchools,
          inactive: inactiveSchools,
          suspended: suspendedSchools,
        },
        branches: {
          total: totalBranches,
          active: activeBranches,
        },
        users: {
          total: totalUsers,
          owners: totalOwners,
          principals: totalPrincipals,
          admins: totalAdmins,
          teachers: totalTeachers,
          students: totalStudents,
          parents: totalParents,
        },
      },
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// GET ALL SCHOOLS
// SEARCH + FILTER + PAGINATION
// ======================================

exports.getAllSchools = async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);

    const limit = Math.min(
      Math.max(parseInt(req.query.limit, 10) || 10, 1),
      100
    );

    const skip = (page - 1) * limit;

    const { search, status } = req.query;

    const filter = {};

    // Search by school name, email or school code
    if (search && search.trim()) {
      const escapedSearch = search.trim().replace(
        /[.*+?^${}()|[\]\\]/g,
        "\\$&"
      );

      const searchRegex = new RegExp(escapedSearch, "i");

      filter.$or = [
        { name: searchRegex },
        { email: searchRegex },
        { schoolCode: searchRegex },
      ];
    }

    // Filter by school status
    if (status) {
      if (!["active", "inactive", "suspended"].includes(status)) {
        return res.status(400).json({
          success: false,
          message: "Invalid school status filter",
        });
      }

      filter.status = status;
    }

    const [schools, totalSchools] = await Promise.all([
      School.find(filter)
        .populate("owner", "name email phone")
        .sort({ _id: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),

      School.countDocuments(filter),
    ]);

    return res.status(200).json({
      success: true,
      message: "Schools fetched successfully",
      pagination: {
        total: totalSchools,
        page,
        limit,
        totalPages: Math.ceil(totalSchools / limit),
        hasNextPage: page * limit < totalSchools,
        hasPrevPage: page > 1,
      },
      count: schools.length,
      schools,
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// GET SINGLE SCHOOL DETAILS
// ======================================

exports.getSchoolDetails = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid school ID",
      });
    }

    const school = await School.findById(id)
      .populate("owner", "name email phone status")
      .lean();

    if (!school) {
      return res.status(404).json({
        success: false,
        message: "School not found",
      });
    }

    const [
      branches,
      totalBranches,
      activeBranches,
      totalUsers,
    ] = await Promise.all([
      Branch.find({ school: id })
        .select("name branchCode email phone address status")
        .sort({ _id: -1 })
        .lean(),

      Branch.countDocuments({ school: id }),

      Branch.countDocuments({
        school: id,
        status: "active",
      }),

      User.countDocuments({
        school: id,
        roles: { $ne: "super_admin" },
      }),
    ]);

    return res.status(200).json({
      success: true,
      message: "School details fetched successfully",
      school,
      statistics: {
        totalBranches,
        activeBranches,
        inactiveBranches: totalBranches - activeBranches,
        totalUsers,
      },
      branches,
    });
  } catch (error) {
    next(error);
  }
};
