
const User = require("../models/User");
const School = require("../models/School");
const Branch = require("../models/Branch");

// ======================================
// 1. OVERVIEW REPORT
// ======================================
exports.getOverviewReport = async (req, res, next) => {
  try {
    const [
      totalSchools,
      activeSchools,
      inactiveSchools,
      totalBranches,
      activeBranches,
      inactiveBranches,
      totalUsers,
      activeUsers,
      inactiveUsers,
    ] = await Promise.all([
      School.countDocuments(),
      School.countDocuments({ status: "active" }),
      School.countDocuments({ status: "inactive" }),

      Branch.countDocuments(),
      Branch.countDocuments({ status: "active" }),
      Branch.countDocuments({ status: "inactive" }),

      User.countDocuments(),
      User.countDocuments({ status: "active" }),
      User.countDocuments({ status: "inactive" }),
    ]);

    return res.status(200).json({
      success: true,
      report: {
        schools: {
          total: totalSchools,
          active: activeSchools,
          inactive: inactiveSchools,
        },
        branches: {
          total: totalBranches,
          active: activeBranches,
          inactive: inactiveBranches,
        },
        users: {
          total: totalUsers,
          active: activeUsers,
          inactive: inactiveUsers,
        },
      },
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// 2. ROLE-WISE USERS REPORT
// ======================================
exports.getRoleWiseUsersReport = async (req, res, next) => {
  try {
    const roles = [
      "super_admin",
      "owner",
      "principal",
      "admin",
      "teacher",
      "student",
      "parent",
    ];

    const report = await User.aggregate([
      {
        $group: {
          _id: "$role",
          total: { $sum: 1 },
          active: {
            $sum: {
              $cond: [{ $eq: ["$status", "active"] }, 1, 0],
            },
          },
          inactive: {
            $sum: {
              $cond: [{ $eq: ["$status", "inactive"] }, 1, 0],
            },
          },
        },
      },
    ]);

    const formattedReport = roles.map((role) => {
      const found = report.find((item) => item._id === role);

      return {
        role,
        total: found ? found.total : 0,
        active: found ? found.active : 0,
        inactive: found ? found.inactive : 0,
      };
    });

    return res.status(200).json({
      success: true,
      count: formattedReport.length,
      report: formattedReport,
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// 3. SCHOOL-WISE USERS AND BRANCHES REPORT
// ======================================
exports.getSchoolWiseReport = async (req, res, next) => {
  try {
    const report = await School.aggregate([
      {
        $lookup: {
          from: Branch.collection.name,
          localField: "_id",
          foreignField: "school",
          as: "branches",
        },
      },
      {
        $lookup: {
          from: User.collection.name,
          localField: "_id",
          foreignField: "school",
          as: "users",
        },
      },
      {
        $project: {
          name: 1,
          schoolCode: 1,
          status: 1,

          totalBranches: { $size: "$branches" },

          activeBranches: {
            $size: {
              $filter: {
                input: "$branches",
                as: "branch",
                cond: { $eq: ["$$branch.status", "active"] },
              },
            },
          },

          inactiveBranches: {
            $size: {
              $filter: {
                input: "$branches",
                as: "branch",
                cond: { $eq: ["$$branch.status", "inactive"] },
              },
            },
          },

          totalUsers: { $size: "$users" },

          activeUsers: {
            $size: {
              $filter: {
                input: "$users",
                as: "user",
                cond: { $eq: ["$$user.status", "active"] },
              },
            },
          },

          inactiveUsers: {
            $size: {
              $filter: {
                input: "$users",
                as: "user",
                cond: { $eq: ["$$user.status", "inactive"] },
              },
            },
          },
        },
      },
      {
        $sort: { name: 1 },
      },
    ]);

    return res.status(200).json({
      success: true,
      count: report.length,
      report,
    });
  } catch (error) {
    next(error);
  }
};
