
const TeacherProfile = require("../models/TeacherProfile");
const createProfileController = require("../utils/profileControllerFactory");

module.exports = createProfileController(
  TeacherProfile,
  "teacher",
  [
    "branch",
    "employeeId",
    "qualification",
    "specialization",
    "subjects",
    "phone",
    "address",
    "joiningDate",
    "employmentType",
    "status",
  ],
  ["owner", "principal", "admin"]
);
