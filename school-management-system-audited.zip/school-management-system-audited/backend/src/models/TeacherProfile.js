
const mongoose = require("mongoose");

const teacherProfileSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "School",
      required: true,
    },

    branch: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Branch",
      required: true,
    },

    employeeId: {
      type: String,
      required: true,
      trim: true,
    },

    qualification: {
      type: String,
      trim: true,
      default: "",
    },

    specialization: {
      type: String,
      trim: true,
      default: "",
    },

    subjects: [
      {
        type: String,
        trim: true,
      },
    ],

    phone: {
      type: String,
      trim: true,
      default: "",
    },

    address: {
      type: String,
      trim: true,
      default: "",
    },

    joiningDate: {
      type: Date,
      default: null,
    },

    employmentType: {
      type: String,
      enum: ["Permanent", "Contract", "Visiting"],
      default: "Permanent",
    },

    status: {
      type: String,
      enum: ["Active", "Inactive", "Resigned"],
      default: "Active",
    },
  },
  {
    timestamps: true,
  }
);

teacherProfileSchema.index({ school: 1, user: 1 }, { unique: true });
teacherProfileSchema.index({ school: 1, employeeId: 1 }, { unique: true });

module.exports = mongoose.model("TeacherProfile", teacherProfileSchema);
