
const mongoose = require("mongoose");

const adminProfileSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "School",
      required: true,
    },

    branches: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Branch",
      },
    ],

    employeeId: {
      type: String,
      required: true,
      trim: true,
    },

    designation: {
      type: String,
      trim: true,
      default: "",
    },

    phone: {
      type: String,
      trim: true,
      default: "",
    },

    address: {
      type: String,
      trim: true,
      default: "",
    },

    joiningDate: {
      type: Date,
      default: null,
    },

    status: {
      type: String,
      enum: ["Active", "Inactive", "Resigned"],
      default: "Active",
    },
  },
  {
    timestamps: true,
  }
);

adminProfileSchema.index({ school: 1, user: 1 }, { unique: true });
adminProfileSchema.index({ school: 1, employeeId: 1 }, { unique: true });

module.exports = mongoose.model("AdminProfile", adminProfileSchema);
