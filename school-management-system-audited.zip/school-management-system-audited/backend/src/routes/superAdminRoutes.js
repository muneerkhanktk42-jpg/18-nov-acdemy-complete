
const express = require("express");
const router = express.Router();

// ======================================
// CONTROLLERS
// ======================================

// Authentication
const { superAdminLogin } = require("../controllers/authController");

// Dashboard
const {
  getDashboardStats,
  getAllSchools,
  getSchoolDetails,
} = require("../controllers/superAdminDashboardController");

// Users
const {
  getAllUsers,
  getUserDetails,
  updateUserStatus,
} = require("../controllers/superAdminUserController");

// Branches
const {
  getAllBranches,
  getBranchDetails,
  updateBranchStatus,
} = require("../controllers/superAdminBranchController");

// Reports
const {
  getOverviewReport,
  getRoleWiseUsersReport,
  getSchoolWiseReport,
} = require("../controllers/superAdminReportController");

// Settings
const {
  getMyProfile,
  updateMyProfile,
  changeMyPassword,
} = require("../controllers/superAdminSettingsController");

// School Management
const { updateSchoolStatus } = require("../controllers/schoolController");

// ======================================
// MIDDLEWARES
// ======================================

const { protect } = require("../middlewares/authMiddleware");
const { authorizeRoles } = require("../middlewares/roleMiddleware");

const superAdminOnly = authorizeRoles("super_admin");

// ======================================
// SUPER ADMIN LOGIN
// ======================================

router.post("/login", superAdminLogin);

// ======================================
// PROTECT ALL ROUTES BELOW
// ======================================

router.use(protect, superAdminOnly);

// ======================================
// DASHBOARD
// ======================================

router.get("/dashboard", getDashboardStats);

// ======================================
// SCHOOLS MANAGEMENT
// ======================================

router.get("/schools", getAllSchools);
router.get("/schools/:id", getSchoolDetails);
router.patch("/schools/:id/status", updateSchoolStatus);

// ======================================
// USERS MANAGEMENT
// ======================================

router.get("/users", getAllUsers);
router.get("/users/:id", getUserDetails);
router.patch("/users/:id/status", updateUserStatus);

// ======================================
// BRANCHES MANAGEMENT
// ======================================

router.get("/branches", getAllBranches);
router.get("/branches/:id", getBranchDetails);
router.patch("/branches/:id/status", updateBranchStatus);

// ======================================
// REPORTS
// ======================================

router.get("/reports/overview", getOverviewReport);
router.get("/reports/roles", getRoleWiseUsersReport);
router.get("/reports/schools", getSchoolWiseReport);

// ======================================
// SUPER ADMIN SETTINGS
// ======================================

router.get("/settings/profile", getMyProfile);

router.patch("/settings/profile", updateMyProfile);

router.patch("/settings/change-password", changeMyPassword);

// ======================================
// EXPORT ROUTER
// ======================================

module.exports = router;
