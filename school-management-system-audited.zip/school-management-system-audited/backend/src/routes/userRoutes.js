
const express = require("express");
const router = express.Router();

const {
  createUser,
  getUsers,
  updateUser,
  deactivateUser,
} = require("../controllers/userController");

const { protect } = require("../middlewares/authMiddleware");
const { authorizeRoles } = require("../middlewares/roleMiddleware");

router.use(protect);

router.post(
  "/",
  authorizeRoles("owner", "principal", "admin", "super_admin"),
  createUser
);

router.get(
  "/",
  authorizeRoles("owner", "principal", "admin", "super_admin"),
  getUsers
);

router.put(
  "/:id",
  authorizeRoles("owner", "principal", "admin", "super_admin"),
  updateUser
);

router.patch(
  "/:id/deactivate",
  authorizeRoles("owner", "principal", "admin", "super_admin"),
  deactivateUser
);

module.exports = router;
